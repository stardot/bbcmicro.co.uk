TestSuite
---------

This code is under a public domain license. It was downloaded from http://modelb.bbcmicro.com/testsuite-2.15.tar.gz and used with information from http://www.softwolves.com/arkiv/cbm-hackers/7/7114.html (saved here too as `cbm-hackers-post.html`)

The source is in the git history for posterity, but to keep things clean, I've removed anything not needed to run the tests.

Please note the first file run is `" start"` - that is, it has a leading space, presumably to keep it at the top of the directory listing when iterating through the files.
